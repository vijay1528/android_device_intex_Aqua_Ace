#used to add device to CM's lunch
add_lunch_combo cm_Aqua_Ace-eng
add_lunch_combo cm_Aqua_Ace-userdebug
add_lunch_combo cm_Aqua_Ace-user
